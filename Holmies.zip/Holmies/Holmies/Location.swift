//
//  Location.swift
//  Holmies
//
//  Created by Leonardo Geus on 17/09/15.
//  Copyright (c) 2015 Leonardo Geus. All rights reserved.
//

import UIKit


class Location: NSObject {
    
    var location = CLLocation()
    var address = [String]()
    
    
}
