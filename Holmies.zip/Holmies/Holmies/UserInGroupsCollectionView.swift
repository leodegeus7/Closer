//
//  UserInGroupsCollectionView.swift
//  Holmies
//
//  Created by Leonardo Geus on 14/10/15.
//  Copyright © 2015 Leonardo Geus. All rights reserved.
//

import UIKit

class UserInGroupsCollectionView: UICollectionView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    

}
