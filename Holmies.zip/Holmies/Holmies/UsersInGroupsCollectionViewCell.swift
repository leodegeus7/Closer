//
//  UsersInGroupsCollectionViewCell.swift
//  Holmies
//
//  Created by Leonardo Geus on 14/10/15.
//  Copyright © 2015 Leonardo Geus. All rights reserved.
//

import UIKit

class UsersInGroupsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageUser: UIImageView!
    


}


